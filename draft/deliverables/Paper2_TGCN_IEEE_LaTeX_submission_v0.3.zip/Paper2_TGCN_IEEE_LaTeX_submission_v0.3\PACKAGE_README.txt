This package contains the Paper 2 manuscript source organized alongside the IEEE TGCN LaTeX template files.

manuscript/   Paper 2 source, supplement, figures, tables, bibliography, and build script
IEEE_template/  Original IEEE TGCN accepted-manuscript LaTeX template files supplied by IEEE
